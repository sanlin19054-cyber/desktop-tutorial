#ifndef STP23L_H
#define STP23L_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f4xx_hal.h"

#define STP23L_DMA_BUFFER_SIZE        512U
#define STP23L_FRAME_SIZE             195U
#define STP23L_SAMPLE_COUNT           12U
#define STP23L_INVALID_DISTANCE_MM  0xFFFFU

typedef struct
{
    UART_HandleTypeDef *uart;
    uint8_t dma_buffer[STP23L_DMA_BUFFER_SIZE];
    uint8_t frame_buffer[STP23L_FRAME_SIZE];
    uint16_t frame_position;
    volatile uint16_t distance_mm;
    volatile uint8_t confidence;
    volatile uint8_t valid;
    volatile uint8_t restart_requested;
    volatile uint32_t last_update_ms;
    volatile uint32_t frame_count;
    volatile uint32_t invalid_frame_count;
    volatile uint32_t uart_error_count;
} Stp23l;

void Stp23l_Init(Stp23l *sensor, UART_HandleTypeDef *uart);
HAL_StatusTypeDef Stp23l_Start(Stp23l *sensor);
void Stp23l_Service(Stp23l *sensor);
void Stp23l_OnRxHalfComplete(Stp23l *sensor, UART_HandleTypeDef *uart);
void Stp23l_OnRxComplete(Stp23l *sensor, UART_HandleTypeDef *uart);
void Stp23l_OnUartError(Stp23l *sensor, UART_HandleTypeDef *uart);
uint8_t Stp23l_GetDistance(
    const Stp23l *sensor,
    uint32_t now_ms,
    uint32_t maximum_age_ms,
    uint16_t *distance_mm
);

#ifdef __cplusplus
}
#endif

#endif
