#ifndef PI_PROTOCOL_H
#define PI_PROTOCOL_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f4xx_hal.h"

#define PI_PROTOCOL_VERSION       1U
#define PI_PROTOCOL_MAX_PAYLOAD 128U

typedef enum
{
    PI_MSG_HELLO = 0x01,
    PI_MSG_HEARTBEAT = 0x02,
    PI_MSG_DETECTION = 0x10,
    PI_MSG_FRAME_DONE = 0x11,
    PI_MSG_MOTOR_COMMAND = 0x20,
    PI_MSG_ENCODER_TELEMETRY = 0x30,
    PI_MSG_DISTANCE_TELEMETRY = 0x31,
    PI_MSG_ACK = 0x80,
    PI_MSG_STATUS = 0x81
} PiMessageType;

typedef struct
{
    int16_t motor_1;
    int16_t motor_2;
    int16_t motor_3;
    uint16_t ttl_ms;
} PiMotorCommand;

typedef struct
{
    uint8_t class_id;
    uint16_t confidence_milli;
    int16_t center_x_milli;
    int16_t center_y_milli;
    uint16_t width_milli;
    uint16_t height_milli;
    uint16_t distance_mm;
    uint16_t track_id;
    uint32_t received_at_ms;
} PiDetection;

typedef struct
{
    UART_HandleTypeDef *uart;
    uint8_t rx_byte;
    uint8_t frame_buffer[6U + PI_PROTOCOL_MAX_PAYLOAD + 2U];
    uint16_t frame_length;
    uint16_t expected_length;
    uint8_t parser_state;
    volatile uint8_t motor_command_pending;
    volatile uint8_t motor_command_seen;
    volatile uint8_t detection_valid;
    PiMotorCommand motor_command;
    PiDetection latest_detection;
    volatile uint32_t last_motor_command_ms;
    volatile uint32_t last_heartbeat_ms;
    uint16_t tx_sequence;
    volatile uint32_t crc_error_count;
    volatile uint32_t length_error_count;
} PiProtocol;

void PiProtocol_Init(PiProtocol *protocol, UART_HandleTypeDef *uart);
HAL_StatusTypeDef PiProtocol_Start(PiProtocol *protocol);
void PiProtocol_OnRxComplete(PiProtocol *protocol, UART_HandleTypeDef *uart);
void PiProtocol_OnUartError(PiProtocol *protocol, UART_HandleTypeDef *uart);
uint8_t PiProtocol_TakeMotorCommand(
    PiProtocol *protocol,
    PiMotorCommand *command
);
uint8_t PiProtocol_IsMotorCommandExpired(
    const PiProtocol *protocol,
    uint32_t now_ms
);
HAL_StatusTypeDef PiProtocol_SendEncoderTelemetry(
    PiProtocol *protocol,
    int32_t encoder_1,
    int32_t encoder_2,
    int32_t encoder_3
);
HAL_StatusTypeDef PiProtocol_SendDistanceTelemetry(
    PiProtocol *protocol,
    uint16_t left_distance_mm,
    uint16_t right_distance_mm,
    uint8_t valid_mask
);

#ifdef __cplusplus
}
#endif

#endif
